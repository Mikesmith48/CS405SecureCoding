// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	// Using the C++ basic string to hold the input from the user, memory allocation is handled dynamically
	// so buffer overflow potential from input is removed. To keep the input below the 20 character amount,
	// a buffer variable is used to check the size of the input, and if it is larger than 20 bytes, an
	// exception is thrown.
	const std::string account_number = "CharlieBrown42";
	char buffer[20];
	std::string user_input;
	std::cout << "Enter a value: ";
	try {
		std::cin >> user_input;
		if (user_input.size() > sizeof(buffer)) {
			throw std::invalid_argument("Input is too long");
		}
	}
	catch (std::invalid_argument e) {
		std::cerr << e.what() << std::endl;
		return -1;
	}

	std::cout << "You entered: " << user_input << std::endl;
	std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
