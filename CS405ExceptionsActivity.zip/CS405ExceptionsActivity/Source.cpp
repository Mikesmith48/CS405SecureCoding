// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// My class for custom exception
class MyCustomException : public std::exception {
    public:
        const char* what() const throw() {
            return "My Custom Exception has been thrown";
        }
};


bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    // Throwing generic exception
    throw std::exception();

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Exception try-catch for generic std::exception
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception& e) {
        std::cout << "Exception thrown in 'do_even_more_custom_application_logic' function!" << std::endl;
        std::cerr << e.what() << std::endl;
    }
    

    // Throwing my custom exception
    throw MyCustomException();
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Throw the exception if trying to divide by zero, i.e. denominator is zero
    if (den == 0) {
        throw std::runtime_error("Math error: Attempted to divide by zero");
    }

    return (num / den);
}

void do_division() noexcept
{

    float numerator = 10.0f;
    float denominator = 0;

    // Exception handler for divide by Zero instances
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // Chose runtime_error as the std::exception exception choice
    catch (std::runtime_error& e) {
        std::cerr << e.what() << std::endl;
    }
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }
    // Catch block my custom exception
    catch (MyCustomException& e) {
        std::cerr << e.what() << std::endl;
        std::cout << "Custom exception was caught" << std::endl;
    }
    // Catch block for generic std::exception(s)
    catch(std::exception& e) {
        std::cerr << e.what() << std::endl;
        std::cout << "Generic exception was caught" << std::endl;
    }
    // Catch block for any unhandled exceptions
    catch (...) {
        std::cerr << "Unhandled exception was caught" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu